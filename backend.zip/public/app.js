let currentDeploymentId = null;
let statusChart = null;
let progressChart = null;

// Initialize charts
function initializeCharts() {
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    statusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Success', 'In Progress', 'Failed'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: ['#4CAF50', '#FFA726', '#EF5350']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    const progressCtx = document.getElementById('progressChart').getContext('2d');
    progressChart = new Chart(progressCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Download Progress (%)',
                data: [],
                backgroundColor: '#2196F3'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

async function startDeployment() {
    const installerPath = document.getElementById('installerPath').value;
    const computerList = document.getElementById('computerList').value
        .split('\n')
        .map(c => c.trim())
        .filter(Boolean);
    
    if (!installerPath || computerList.length === 0) {
        showError('Please provide installer URL and at least one computer');
        return;
    }

    const deployButton = document.getElementById('deployButton');
    deployButton.disabled = true;

    try {
        const response = await fetch('/api/deploy', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                computers: computerList, 
                installerUrl: installerPath 
            })
        });

        const data = await response.json();
        if (data.error) {
            throw new Error(data.error);
        }

        currentDeploymentId = data.deploymentId;
        document.getElementById('currentDeployment').style.display = 'block';
        document.querySelector('.charts-container').style.display = 'grid';
        initializeCharts();
        updateCharts(data);
        pollDeploymentStatus();
    } catch (error) {
        showError(error.message);
        deployButton.disabled = false;
    }
}

function updateCharts(deployment) {
    if (!deployment.computers) return;

    const stats = {
        success: 0,
        inProgress: 0,
        failed: 0
    };

    const progressData = deployment.computers.map(c => ({
        name: c.name,
        progress: c.downloadProgress || 0
    }));

    deployment.computers.forEach(c => {
        if (c.status === 'success') stats.success++;
        else if (c.status === 'failed') stats.failed++;
        else stats.inProgress++;
    });

    statusChart.data.datasets[0].data = [
        stats.success,
        stats.inProgress,
        stats.failed
    ];
    statusChart.update();

    progressChart.data.labels = progressData.map(d => d.name);
    progressChart.data.datasets[0].data = progressData.map(d => d.progress);
    progressChart.update();
}

async function pollDeploymentStatus() {
    if (!currentDeploymentId) return;

    try {
        const response = await fetch(`/api/deployment/${currentDeploymentId}`);
        const deployment = await response.json();

        updateDeploymentStatus(deployment);
        updateCharts(deployment);

        const isComplete = deployment.computers.every(c => 
            c.status === 'success' || c.status === 'failed'
        );

        if (!isComplete) {
            setTimeout(pollDeploymentStatus, 2000);
        } else {
            document.getElementById('deployButton').disabled = false;
        }
    } catch (error) {
        showError('Failed to fetch deployment status');
    }
}

function updateDeploymentStatus(deployment) {
    const tbody = document.getElementById('deploymentStatus');
    tbody.innerHTML = deployment.computers.map(computer => `
        <tr>
            <td>${computer.name}</td>
            <td>
                <span class="status-badge badge-${computer.status}">
                    ${computer.status}
                </span>
            </td>
            <td>
                <div class="progress-container">
                    <div class="progress-bar" style="width: ${computer.downloadProgress}%">
                        <span class="progress-text">${computer.downloadProgress}%</span>
                    </div>
                </div>
            </td>
            <td>
                <span class="status-badge badge-${computer.robotStatus || 'pending'}">
                    ${computer.robotStatus || 'Pending'}
                </span>
            </td>
            <td>${new Date(computer.startTime).toLocaleString()}</td>
            <td>${computer.details || '-'}</td>
        </tr>
    `).join('');
}

function showError(message) {
    document.getElementById('error').textContent = message;
}